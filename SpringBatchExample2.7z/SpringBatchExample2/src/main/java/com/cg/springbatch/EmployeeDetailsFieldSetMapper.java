package com.cg.springbatch;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import com.cg.springbatch.model.EmployeeDetails;

public class EmployeeDetailsFieldSetMapper implements FieldSetMapper<EmployeeDetails>{

	@Override
	public EmployeeDetails mapFieldSet(FieldSet fieldSet) throws BindException {
		EmployeeDetails emp = new EmployeeDetails();
		emp.setId(fieldSet.readInt(0));
		emp.setName(fieldSet.readString(1));
		emp.setSalary(fieldSet.readLong(2));
		return emp;
	}

}
