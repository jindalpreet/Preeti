package com.cg.springbatch;

import java.util.HashMap;

import org.springframework.batch.item.ItemProcessor;

import com.cg.springbatch.model.EmployeeDetails;

public class EmployeeDetailsItemProcessor implements ItemProcessor<EmployeeDetails, EmployeeDetails>{
	
	@Override
	public EmployeeDetails process(EmployeeDetails emp) throws Exception {
		//System.out.println("Employee Details :"+emp.getClass());
		HashMap<Integer, EmployeeDetails> map = new HashMap<Integer, EmployeeDetails>();
		
		map.put(emp.getId(), emp);
		System.out.println(map.get(emp.getId()));
		/*List empDet=new ArrayList<EmployeeDetails>();
		if(null==map.get(emp.getId())){
			empDet.add(emp);
		map.put(emp.getId(), empDet);
		}
		else{
			
			map.get(emp.getId()).add(emp);
			map.put(emp.getId(),emp)
		}*/
		/*ArrayList<EmployeeDetails> list = new ArrayList<EmployeeDetails>();
		list.add(map.get(emp.getId()));
		for(EmployeeDetails emp1 : list){
			System.out.println(emp1);
		}*/
		
		/*Set keys =  map.keySet();
		for (Integer id : keys) {
			List<EmployeeDetails>emp[id]=new ArrayList<EmployeeDetails>();
			emp[id].add(map.get(id));
			
		}*/
	
		
		//System.out.println(emp.getId());
		
		
		return emp;
	}

}
