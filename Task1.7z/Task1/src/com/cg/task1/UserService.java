package com.cg.task1;

public class UserService {

}
