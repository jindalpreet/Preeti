CREATE TABLE Consumera( consumer_num NUMBER(6) PRIMARY KEY, consumer_name VARCHAR2(20) NOT NULL, address VARCHAR2(30) );

INSERT INTO Consumera VALUES(100001,'Sumeet','Shivaji Nagar, Pune'); 
INSERT INTO Consumera VALUES(100002,'Meenal','M G Colony Panvel, Mumbai'); 
INSERT INTO Consumera VALUES(100003,'Neeraj','Whitefield, Bangalore'); 
INSERT INTO Consumera VALUES(100004,'Arul','Karapakkam, Chennai');
