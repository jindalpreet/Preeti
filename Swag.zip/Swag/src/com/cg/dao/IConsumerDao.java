package com.cg.dao;

import java.util.List;

import com.cg.dto.ConsumerBean;
import com.cg.exception.ConsumerException;

public interface IConsumerDao {
	
	public List<ConsumerBean> getAllConsumer() throws ConsumerException;
}
