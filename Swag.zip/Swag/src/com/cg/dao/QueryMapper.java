package com.cg.dao;

public interface QueryMapper {

	
	public static final String VIEW_CONSUMER_DETAILS_QUERY="SELECT consumer_num,consumer_name,address FROM consumera WHERE  consumer_num=?";
}
