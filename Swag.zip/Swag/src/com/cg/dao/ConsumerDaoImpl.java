package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.dto.ConsumerBean;
import com.cg.exception.ConsumerException;
import com.cg.util.DbConnection;

public class ConsumerDaoImpl implements IConsumerDao {

	@Override
	public List<ConsumerBean> getAllConsumer() throws ConsumerException {

List<ConsumerBean>consumerList= new ArrayList<ConsumerBean>();
		
		try(
				Connection conn= DbConnection.getConnection();	
				PreparedStatement preparedStatement=conn.prepareStatement(QueryMapper.VIEW_CONSUMER_DETAILS_QUERY);
				ResultSet rs = preparedStatement.executeQuery();
				){
												
					while(rs.next()){
						ConsumerBean consumer = new ConsumerBean();
						
						consumer.setConsumer_num(rs.getInt(1));
						consumer.setConsumer_name(rs.getString(2));
						consumer.setAdd(rs.getString(3));
					
						
						consumerList.add(consumer);
					}
					
					if(consumerList.size() == 0){
						throw new ConsumerException("No records found");
					}
		}
		catch(SQLException sqlEx){
			throw new ConsumerException(sqlEx.getMessage());
		
	}
		
		
		return consumerList;
	}

}
