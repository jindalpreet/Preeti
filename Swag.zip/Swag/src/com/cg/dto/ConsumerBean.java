package com.cg.dto;

public class ConsumerBean {
	private int consumer_num;
	private String consumer_name;
	private String add;
	public int getConsumer_num() {
		return consumer_num;
	}
	public void setConsumer_num(int consumer_num) {
		this.consumer_num = consumer_num;
	}
	public String getConsumer_name() {
		return consumer_name;
	}
	public void setConsumer_name(String consumer_name) {
		this.consumer_name = consumer_name;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}
	public ConsumerBean(int consumer_num, String consumer_name, String add) {
		super();
		this.consumer_num = consumer_num;
		this.consumer_name = consumer_name;
		this.add = add;
	}
	public ConsumerBean() {
		super();
	}
	@Override
	public String toString() {
		return "ConsumerBean [consumer_num=" + consumer_num
				+ ", consumer_name=" + consumer_name + ", add=" + add + "]";
	}
	
	
	

}
