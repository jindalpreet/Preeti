package com.cg.exception;

public class ConsumerException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6489574063513948253L;
	public ConsumerException(String message) 
	{
		
		super(message);
	}

}
