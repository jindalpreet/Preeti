package com.cg.service;

import java.util.List;

import com.cg.dto.ConsumerBean;
import com.cg.exception.ConsumerException;

public interface IServiceConsumer {

	public List<ConsumerBean> getAllConsumer()throws ConsumerException;
}
