package com.cg.service;

import java.util.List;

import com.cg.dao.ConsumerDaoImpl;
import com.cg.dao.IConsumerDao;
import com.cg.dto.ConsumerBean;
import com.cg.exception.ConsumerException;

public class ConsumerServiceImpl implements IServiceConsumer {

	IConsumerDao consumerDao = new ConsumerDaoImpl();
	@Override
	public List<ConsumerBean> getAllConsumer() throws ConsumerException {
		List<ConsumerBean> consumerList = consumerDao.getAllConsumer();
	
		
		return consumerList;
	}

}
