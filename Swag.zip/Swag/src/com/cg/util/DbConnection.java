package com.cg.util;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.exception.ConsumerException;






/**
 * Author 		: GUNJAN 
 * Class Name 	: DbConnection
 * Package 		: com.capgemini.assignment5.utility
 * Date 		: Nov 28, 2017
 */

public class DbConnection {
	public static Connection getConnection() throws ConsumerException {
		Connection conn = null;

		try {
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/OracleDS");
			conn = ds.getConnection();
		}

		catch (SQLException e) {
			throw new ConsumerException("SQL Error:"+e.getMessage());
		} catch (NamingException e) {
			throw new ConsumerException("message from DB/NamingExc:"
					+ e.getMessage());
		}
		return conn;
	}

	public static Statement getInstance() {
		// TODO Auto-generated method stub
		return null;
	}
}
