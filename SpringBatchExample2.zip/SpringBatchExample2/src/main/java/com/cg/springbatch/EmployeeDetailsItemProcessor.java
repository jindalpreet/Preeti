package com.cg.springbatch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.springframework.batch.item.ItemProcessor;

import com.cg.springbatch.model.EmployeeDetails;

public class EmployeeDetailsItemProcessor implements ItemProcessor<EmployeeDetails, EmployeeDetails>{
	
	@Override
	public EmployeeDetails process(EmployeeDetails emp) throws Exception {

		BufferedWriter bufferWriter = null;
		FileWriter fileWriter = null;
		int id = emp.getId();
		File empFile = new File("xml/employeeDetails"+id+".txt");
//Doesnt Exists
		if (!empFile.exists())
		{
			empFile.createNewFile();
		}
//If exists
		fileWriter = new FileWriter(empFile.getAbsoluteFile(), true);
		bufferWriter = new BufferedWriter(fileWriter);
		String employeeResults=emp.toString();
		
		
		byte[] bytes = Files.readAllBytes(Paths.get("xml/employeeDetails"+id+".txt"));
		String s = new String(bytes);
		// Check if the name is contained
		if(s.indexOf(employeeResults) != -1){
		     System.out.println("Name already present!");
		} else {
			bufferWriter.write("\n");
			bufferWriter.write(employeeResults);
			bufferWriter.close();
			System.out.println("Done"); 
			
		}
	
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String date = simpleDateFormat.format(new Date());
		String fileName = "Employee"+"_"+date+".zip";
		FileOutputStream fos = new FileOutputStream(fileName);
		//FileOutputStream fos = new FileOutputStream("Final"+id+".zip"); 
		ZipOutputStream zipOS = new ZipOutputStream(fos); 	
		File empfolder = new File("xml");
		File[] listOfFiles = empfolder.listFiles();
			
		 
		 for (int i = 0; i < listOfFiles.length; i++) {
		      if (listOfFiles[i].isFile()) {
		    	  FileInputStream fis = new FileInputStream(listOfFiles[i].toString());
		  		ZipEntry zipEntry = new ZipEntry(listOfFiles[i].toString()); 
		  		zipOS.putNextEntry(zipEntry); 
		  		byte[] by = new byte[1024]; 
		  		int length;
		  		while ((length = fis.read(by)) >= 0) 
		  		{ 
		  			zipOS.write(by, 0, length); 
		  		}
		  		zipOS.closeEntry(); fis.close(); 
		      }
		    }
	
		 
	InputStream inStream = null;
	OutputStream outStream = null;
		
    	try{
    		
    	    File afile =new File(fileName);
    	    File bfile =new File("C:/Users/prejinda/workspace/SpringBatchExample2/File/"+ afile.getName());
    		
    	    inStream = new FileInputStream(afile);
    	    outStream = new FileOutputStream(bfile);
        	
    	    byte[] buffer = new byte[1024];
    		
    	    int length;
    	    //copy the file content in bytes 
    	    while ((length = inStream.read(buffer)) > 0){
    	  
    	    	outStream.write(buffer, 0, length);
    	 
    	    }
    	    afile.delete();
    	    inStream.close();
    	    outStream.close();
    	    
    	   
    	   

    	    	    
    	    //delete the original file
    	   
    	    
    	    System.out.println("File is copied successfully!");
    	    
    	}catch(IOException e){
    	    e.printStackTrace();
    	}
      
    	 
        System.out.println(emp);
		return emp;
	

	}
}