package com.capgemini.l3;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAccessor;

public class person {
	private String firstName;
	private String lastName;
	private Gender gender;
	private String phone;
	private String dob;
	private static long age;
	private static String fullname;
	
	public person() {
	}

	public person(String firstName, String lastName, Gender gender, String phone,String dob) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.phone = phone;
		this.dob = dob;
	}

	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}
	
	public static void calAge(String dob){
		
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		TemporalAccessor ta =  dtf.parse(dob);
		LocalDate ld = LocalDate.from(ta);
		
		age = ChronoUnit.YEARS.between(ld, LocalDate.now());
	}
	
	public static void FullName(String firstName, String lastName){
		
		fullname  = firstName + " " + lastName;
		
	}
	
	@Override
	public String toString() {
		return "Person Details: \n_______________\n\nFull Name: " + fullname + "\nGender: " + gender + "\nPhone Number: " + phone + "\nAge: " + age;
	}
	
}
