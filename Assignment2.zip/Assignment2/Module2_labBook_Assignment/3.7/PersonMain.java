package com.capgemini.l3;

import java.util.Scanner;

public class PersonMain {

	public static void main(String[] args) {
		person Person;
		String fname;
		String lname;
		Gender gender;
		Scanner scanf = new Scanner(System.in);
		
		
		System.out.println("Enter the First Name: ");
		fname = scanf.nextLine();
		System.out.println("Enter the Last Name: ");
		lname = scanf.nextLine();
		
		System.out.println("Enter the phone number: ");
		String phone = scanf.nextLine();
		System.out.println("Enter the Date of Birth in dd/MM/yyyy format: ");
		String dob = scanf.nextLine();
		System.out.println("Enter the Gender: ");
		gender = Gender.valueOf(scanf.nextLine());
		
		
		Person = new person(fname,lname,gender,phone,dob);
		
		person.calAge(dob);
		person.FullName(fname,lname);
		
		System.out.println(Person);
		
		scanf.close();
	}


	
}