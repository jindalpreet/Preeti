package com.capgemini.employee.dao;

public class QueryMapperEmployees {

	public static final String INSERT_EMPLOYEES = 
			"INSERT INTO employees VALUES(?,?,?)";
	
	public static final String DELETE_EMPLOYEES = 
			"DELETE FROM employees WHERE id =?";
	
	public static final String VIEW_EMPLOYEES =
			"SELECT id,name,salary FROM employees";
}
