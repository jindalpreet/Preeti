package com.capgemini.employee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.exception.EmployeesException;
import com.capgemini.employee.util.DBConnection;

public class EmployeesDAOImpl implements IEmployeeDAO {
	
	
	@Override
	public boolean insertEmployee(EmployeeBean employeeBean)
			throws EmployeesException {
		int records = 0;
		boolean isInserted = false;
		try(
				Connection connPurchaseDetails= DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=connPurchaseDetails.prepareStatement(QueryMapperEmployees.INSERT_EMPLOYEES);
			){
		
			
			
			preparedStatement.setInt(1, employeeBean.getId());
			preparedStatement.setString(2, employeeBean.getName());
			preparedStatement.setFloat(3, employeeBean.getSalary());
			
			records = preparedStatement.executeUpdate();
			
			if(records > 0){
				isInserted = true;
			}
		}
		
		catch(SQLException sqlEx){
			throw new EmployeesException(sqlEx.getMessage());
		}
			return isInserted;
		}
	

	@Override
	public boolean deleteEmployee(int id) throws EmployeesException {
		int records = 0;
		boolean isDeleted = false;
		try(
				Connection connPurchaseDetails= DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=
					connPurchaseDetails.prepareStatement(QueryMapperEmployees.DELETE_EMPLOYEES);
			){
						
			preparedStatement.setInt(1,id);
						
			records = preparedStatement.executeUpdate();
			
			if(records > 0){
				isDeleted  = true;
			}
		}
		
		catch(SQLException sqlEx){
			throw new EmployeesException(sqlEx.getMessage());
		}
		return isDeleted;
	}

	@Override
	public List<EmployeeBean> viewAll() throws EmployeesException {
			
		List<EmployeeBean>mobileList= new ArrayList<EmployeeBean>();
		
		try(
				Connection connMobile= DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=connMobile.prepareStatement(QueryMapperEmployees.VIEW_EMPLOYEES);
				ResultSet rsMobiles = preparedStatement.executeQuery();
				){
												
					while(rsMobiles.next()){
						EmployeeBean mobile = new EmployeeBean();
						
						mobile.setId(rsMobiles.getInt("id"));
						mobile.setName(rsMobiles.getString("name"));
						mobile.setSalary(rsMobiles.getFloat("salary"));
					
						
						mobileList.add(mobile);
					}
					
					if(mobileList.size() == 0){
						throw new EmployeesException("No records found");
					}
		}
		catch(SQLException sqlEx){
			throw new EmployeesException(sqlEx.getMessage());
		}
			return mobileList;
	}
	

}
