package com.capgemini.employee.test;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;

import org.junit.Test;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.exception.EmployeesException;
import com.capgemini.employee.service.IServiceEmployees;
import com.capgemini.employee.service.ServiceEmployeesImpl;

public class ServiceEmployeesImplTest {

	private EmployeeBean employeeBean;
	IServiceEmployees serviceEmployees = new ServiceEmployeesImpl();
	
	
	@Before
	public void setUp() throws Exception {
		employeeBean = new EmployeeBean (105,"abc",20000.00f);
	}

	@After
	public void tearDown() throws Exception {
		employeeBean = null;
	}

	@Test
	public final void testInsertEmployees() {
		
		try{
			assertTrue(serviceEmployees.insertEmployees(employeeBean));
		}
		catch(EmployeesException e)
		{
			e.printStackTrace();
			
		}
	}

	@Test
	public final void testViewAll() {
		try{
			List<EmployeeBean>employeeList = serviceEmployees.viewAll();
			assertTrue("No such mobile", employeeList.size()>0);
		}
	catch(EmployeesException e){
		e.printStackTrace();
	}
	}

	@Test
	public final void testDeleteEmployee() {
		try{
			assertTrue(serviceEmployees.deleteEmployee(103));
		}
		catch(EmployeesException e)
		{
			e.printStackTrace();
			
		}
	}

}
