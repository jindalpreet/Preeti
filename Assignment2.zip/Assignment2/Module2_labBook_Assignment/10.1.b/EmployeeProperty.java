import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;


public class EmployeeProperty {

	private static Properties createDefaultProperties() {

		Properties tempProp = new Properties();
		/* Database connection parameter properties are set */
		tempProp.setProperty("ID","101");
		tempProp.setProperty("Name", "Preeti");
		tempProp.setProperty("Salary", "300000");
		tempProp.setProperty("Designation", "Manager");
		tempProp.setProperty("Insurance_Scheme", "Scheme A");
		return tempProp;
	}
	
	
	private static void saveProperties(Properties p, String fileName) {
		OutputStream propsFile;

		try {
			propsFile = new FileOutputStream(fileName);
			p.store(propsFile, "Properties File to the Test Application");
			propsFile.close();
		} catch (IOException ioe) {
			System.out.println("I/O Exception.");
			ioe.printStackTrace();
			System.exit(0);
		}

	}
	
	public static void main(String[] args) {
		
		final String PROPFILE = "PersonProps.properties";
		Properties myProp;
		Properties myNewProp;
		
		myProp = createDefaultProperties();
		saveProperties(myProp, PROPFILE);
		System.out.println("ID: "+myProp.getProperty("ID"));
		System.out.println("Name: "+myProp.getProperty("Name"));
		System.out.println("Salary: "+myProp.getProperty("Salary"));
		System.out.println("Designation: "+myProp.getProperty("Designation"));
		System.out.println("Insurance Scheme: "+myProp.getProperty("Insurance_Scheme"));
		
	}

}
