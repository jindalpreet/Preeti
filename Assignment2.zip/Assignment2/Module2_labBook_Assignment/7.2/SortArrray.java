package com.capgemini.l7;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class SortArrray {

	public static void main(String[] args) {
		String str;
		Scanner scInput = new Scanner(System.in);
		System.out.println("Enter 5 names: \n");
		ArrayList<String> li = new ArrayList<String>();
		for(int i = 0; i < 5; i++){
			str = scInput.nextLine();
			li.add(str);
		}
        
        //System.out.println("List: "+li);
        //create a treeset with the list
        TreeSet<String> myset = new TreeSet<String>(li);
        Iterator<String> it = myset.iterator();
        
        System.out.println("\n\nAfter sorting\n");
        while (it.hasNext()) {
            System.out.println(it.next());
        }


		scInput.close();
	}

}
