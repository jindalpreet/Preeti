package com.capgemini.Lab13_1;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class CopyDataThread extends Thread {
	private FileInputStream fis;
	private FileOutputStream fos;

	public CopyDataThread(FileInputStream fis, FileOutputStream fos) {
		this.fis = fis;
		this.fos = fos;
	}

	@Override
	public void run() {
		int ch;
		try {
			int c = 0;
			while ((ch = fis.read()) != -1) {
				
				if (c == 10) {
					System.out.println("10 characters are copied");
					this.sleep(5000);
					c = 0;
				}
				fos.write((char) ch);
				c++;
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
