package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.DesignationEmployee;
import com.cg.eis.service.EmployeeServiceImpl;
import com.cg.eis.service.InsuranceScheme;

public class ClientInput {
	
	

	public static void main(String[] args) {
		
		int id;
		String name;
		double salary;
		DesignationEmployee designation = null;
		InsuranceScheme insuranceScheme = null;
		Employee employee;
		EmployeeServiceImpl employeeServiceImpl = new EmployeeServiceImpl();
		Scanner scInput = new Scanner(System.in);
		int choice;

		while(true){
			
			System.out.println("Enter 1 to register user details : ");
			System.out.println("Enter 2 to get user details based on insurance scheme : ");
			System.out.println("Enter 3 to delete an employee detail : ");
			System.out.println("Enter 4 to display user details based on salary: ");
			System.out.println("Enter 5 to Quit: \n");
			
			choice = scInput.nextInt();
					scInput.nextLine();	
			
			if(choice == 5){
				System.out.println("END");
				break; // End the While loop
			}
			
			switch(choice){
			
				case 1: 
						System.out.println("Enter id : ");
						id = scInput.nextInt();
						scInput.nextLine();
				
						System.out.println("Enter name : ");
						name = scInput.nextLine();
				
						System.out.println("Enter salary : ");
						salary = scInput.nextDouble();
			
						EmployeeException.checkSalary(salary);

						if(salary > 5000 && salary < 20000){
							insuranceScheme=InsuranceScheme.Scheme_C;
							designation=DesignationEmployee.System_Associate;
					
						}
						else if(salary >= 20000 && salary < 40000){
							insuranceScheme=InsuranceScheme.Scheme_B;
							designation=DesignationEmployee.Programmer;
						}
						else if(salary >= 40000){
							insuranceScheme=InsuranceScheme.Scheme_A;
							designation=DesignationEmployee.Manager;
						}
						else if(salary <= 5000){
							insuranceScheme=InsuranceScheme.No_Scheme;
							designation=DesignationEmployee.Clerk;
						}
						employee = new Employee(id,name,salary,designation,insuranceScheme);
						employeeServiceImpl.addEmployee(employee);
						
						break;
						
						
				case 2:
						InsuranceScheme IS = null;
						int ch;
						System.out.println("\nEnter 1 for 'Scheme_A'\nEnter 2 for 'Scheme_B'\nEnter 3 for 'Scheme_C'\nEnter 4 for 'No_Scheme'\n\nEnter : ");
						ch = scInput.nextInt();
						scInput.nextLine();
						
						switch(ch){
							case 1:
									employeeServiceImpl.ISEmployee(IS.Scheme_A);
									break;
							case 2:
								employeeServiceImpl.ISEmployee(IS.Scheme_B);
								break;
							case 3:
								employeeServiceImpl.ISEmployee(IS.Scheme_C);
								break;
							case 4:
								employeeServiceImpl.ISEmployee(IS.No_Scheme);
								break;
						}
						
					break;
					
				case 3:
						System.out.println("Enter id : ");
						id = scInput.nextInt();
						scInput.nextLine();
						employeeServiceImpl.deleteEmployee(id);
						break;
						
				case 4:
						employeeServiceImpl.salaryEmployee();
						break;
					
				default : 
						System.out.println("Please select a valid option\n\n");
						break;
			}
		}
	}

}
