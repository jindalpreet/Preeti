package com.cg.eis.bean;

import com.cg.eis.service.DesignationEmployee;
import com.cg.eis.service.InsuranceScheme;

public class Employee implements Comparable<Employee>{
	public int id;
	public String name;
	public double salary;
	public DesignationEmployee designation;
	public InsuranceScheme insuranceScheme;
	

	public Employee(int id, String name, double salary,
			DesignationEmployee designation, InsuranceScheme insuranceScheme) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.designation = designation;
		this.insuranceScheme = insuranceScheme;
	}

	public Employee() {

	}
	
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public DesignationEmployee getDesignation() {
		return designation;
	}

	public void setDesignation(DesignationEmployee designation) {
		this.designation = designation;
	}

	public InsuranceScheme getInsuranceScheme() {
		return insuranceScheme;
	}

	public void setInsuranceScheme(InsuranceScheme insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}

	public String salaryDetails() {
		return "\n\nEmployee Details\n\nId = " + id + "\nName = " + name + "\nSalary = " + salary
				+ "\nDesignation = " + designation + "\nInsurance Scheme = "
				+ insuranceScheme;
	}
	

	@Override
	public String toString() {
		return "\n\nEmployee Details\n\nId = " + id + "\nName = " + name + "\nSalary = " + salary
				+ "\nDesignation = " + designation + "\nInsurance Scheme = "
				+ insuranceScheme;
	}

	@Override
	public int compareTo(Employee o) {
		
		return (int)(o.salary-(double)this.salary);
	}
	
}
