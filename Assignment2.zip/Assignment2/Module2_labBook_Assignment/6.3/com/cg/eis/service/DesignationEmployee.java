package com.cg.eis.service;

public enum DesignationEmployee {
	System_Associate,Programmer,Manager,Clerk
}
