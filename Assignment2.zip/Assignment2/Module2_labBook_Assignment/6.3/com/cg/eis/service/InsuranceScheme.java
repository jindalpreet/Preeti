package com.cg.eis.service;

public enum InsuranceScheme {
	Scheme_C,Scheme_B,Scheme_A,No_Scheme
}
