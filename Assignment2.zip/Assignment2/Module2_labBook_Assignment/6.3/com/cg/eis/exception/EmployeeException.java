package com.cg.eis.exception;

public class EmployeeException {

	public static void checkSalary(Double salary) {
		
		try {
			if(salary < 3000) {
				throw new Exception();
			}
	} catch(Exception e) {
		System.err.println("\nAttention!! : Salary must be greater than 3000\n");
		e.printStackTrace();
		System.exit(1);
		
	}

	}

}
