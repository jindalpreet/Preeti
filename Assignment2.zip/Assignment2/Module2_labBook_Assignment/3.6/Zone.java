package com.capgemini.l3;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import java.util.TimeZone;
import java.util.Date;

public class Zone {
	
	public static void timeZone(String zoneTime) {
		
        DateFormat formatter = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
        Date fromDate = new Date();
		TimeZone central = TimeZone.getTimeZone(zoneTime);

        formatter.setTimeZone(central);
        System.out.println(formatter.format(fromDate));
		
	}

	public static void main(String[] args) {
		
		int selectZone;
		Scanner scInput = new Scanner(System.in);
		System.out.println("TIME ZONE\n\n1. America/New_York\n2. Europe/London\n3. Asia/Tokyo\n4. US/Pacific\n5. Africa/Cairo\n6.Australia/Sydney\nDefault: Asia/Kolkata\n\nEnter the Zone id: ");
		
		selectZone = scInput.nextInt();
		scInput.close(); 	
		switch(selectZone)
		{
			case 1:
		        	timeZone("America/New_York");
		        	break;
			case 2:
		        	timeZone("Europe/London");
		        	break;
			case 3:
					timeZone("Asia/Tokyo");
					break;
			case 4:
		        	timeZone("US/Pacific");
		        	break;
			case 5:
	        	timeZone("Africa/Cairo");
	        	break;
			case 6:
	        	timeZone("Australia/Sydney");
	        	break;
		    default:
		        	timeZone("Asia/Kolkata");
		        	break;
		}
	}

}
