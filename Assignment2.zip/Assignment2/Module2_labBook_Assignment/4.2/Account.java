
public class Account {
	private long accNum;
	private double balance;
	private Person accHolder;
	private static long index=0;
	//Default Constructor
	public Account() {
	}
	
	//Parameterized Constructor
	public Account(double balance, Person accHolder) {
		index++;
		this.accNum = index;
		this.balance = balance;
		this.accHolder = accHolder;
	}


	//Getter and Setter
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	
	//Deposit Function
	public void deposit(double amount){
		this.balance=this.balance+amount;
	}
	
	//Withdraw Function
	public boolean withdraw(double amount){
		this.balance=this.balance-amount;
		return true;
	}
		
	//Output Function
	/*public void output(){
		System.out.println("Account Number: " +accNum);
		System.out.println("Balance: "+balance);
		System.out.println("Holder Name: "+accHolder.getFirstName());
	}*/
	
	//toString Function
	public String toString(){
		String text = "Account Number: " +accNum + "\n" +
						"Balance: "+balance + "\n" +
						"Holder Name: "+accHolder.getFirstName() + "\n" +
					  "===========================================================\n";
		return text;
	}
}
