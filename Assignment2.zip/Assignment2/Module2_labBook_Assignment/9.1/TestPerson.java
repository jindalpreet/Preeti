import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;


public class TestPerson {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void GetFullName(){
		Person per = new Person("Robert","King");
		assertEquals("Robert King",per.getFullName());
	}
	
	@Test
	public void NullsInName(){
		Person per = new Person("Robert","King");
		assertNotNull("full name null",per.getFullName());
		assertNotNull("First name null",per.getFirstName());
	}

	@Test
	public void GetFirstName(){
		Person per = new Person("Robert","King");
		assertEquals(per.getFirstName(),"Robert");
	}
	
	@Test
	public void GetLastName(){
		Person per = new Person("Robert","King");
		assertEquals(per.getLastName(),"King");
	}
}
