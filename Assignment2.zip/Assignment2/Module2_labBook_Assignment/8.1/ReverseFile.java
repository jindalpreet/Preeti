import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ReverseFile {

  public static void main(String[] args) {

	  try {
		  
    	FileInputStream fin=new FileInputStream("input.txt");   
    	FileOutputStream fout=new FileOutputStream("output.txt");  
    	
        int i=0; 
        String str;
        StringBuilder sb = new StringBuilder();
        
        while((i=fin.read())!=-1){ 
        	sb.append((char)i);
         System.out.print((char)i);      
        }
        
        str = sb.toString();
        String reverse = new StringBuffer(str).reverse().toString();
        
        byte b[]=reverse.getBytes();//converting string into byte array    
        fout.write(b);
        
        fin.close();
        fout.close();
        
    } catch (IOException e) {
      System.err.println(e);
    }
  }
}