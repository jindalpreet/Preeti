package Caller;

public class EnumDemo {
	
	enum Gender{F,M}

}
