public class CommandLineDemo {

	public static void main(String[] args) {
		int num;
		num=Integer.parseInt(args[0]);
		if(num > 0){
			System.out.println(num +" is a positive integer.");
		}else{
			System.out.println(num+" is a negative number");
		}

	}

}