package com.Q12.A3.demo.sample;

import org.apache.log4j.Category;
import org.apache.log4j.Logger;

public class Log4jDemo2 {
//create a logger for Log4jDemo2 class
	Category log;
	public static void main(String args[]) {
			for(int i=1 ; i<50000; i++) {
				System.out.println("Counter = " + i);
				
				//log.debug("This is my debug message. Counter = " + i);
				// write log message statements for remaining priority levels
				//in the same way
			}
	}
}