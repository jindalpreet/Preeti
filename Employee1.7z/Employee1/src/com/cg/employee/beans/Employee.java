package com.cg.employee.beans;

public class Employee {
	
	private int EmpId;
	private String EmpName;
	private long salary;
	public Employee(int empId, String empName, long salary) {
		super();
		EmpId = empId;
		EmpName = empName;
		this.salary = salary;
	}
	public Employee() {
		super();
	}
	public int getEmpId() {
		return EmpId;
	}
	public void setEmpId(int empId) {
		EmpId = empId;
	}
	public String getEmpName() {
		return EmpName;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	public long getSalary() {
		return salary;
	}
	public void setSalary(long salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [EmpId=" + EmpId + ", EmpName=" + EmpName + ", salary=" + salary + "]";
	}
	
	
	
	
	
	

}
