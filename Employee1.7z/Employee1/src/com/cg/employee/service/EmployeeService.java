package com.cg.employee.service;

import java.util.List;

import com.cg.employee.beans.Employee;
import com.cg.employee.dao.EmployeeDaoImpl;
import com.cg.employee.dao.IEmployeeDao;

public class EmployeeService implements IEmployeeService {

	IEmployeeDao dao;
	
	public EmployeeService() {
		dao = new EmployeeDaoImpl();
	}
	
	@Override
	public List<Employee> getAllEmployeeDetails() {
		
		return dao.getAllEmployeeDetails();
	}

	@Override
	public Employee getEmployee(int id) {
		return dao.getEmployee(id);
	}

	@Override
	public Employee addEmployee(Employee employee) {
		return dao.addEmployee(employee);
	}

	@Override
	public Employee deleteEmployee(int id) {
		return dao.deleteEmployee(id);
	}

}
