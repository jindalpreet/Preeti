package com.cg.employee.staticDB;

import java.util.HashMap;

import com.cg.employee.beans.Employee;

public class EmployeeDB {

static HashMap<Integer, Employee> employeeIdMap = getEmployeeIdMap();
	
	static {
		if (employeeIdMap == null) {
			employeeIdMap = new HashMap<Integer, Employee>();
			Employee emp1 = new Employee(1, "Preeti", 10000);
			Employee emp2 = new Employee(4, "Saloni", 20000);
			Employee emp3 = new Employee(3, "Simran", 18000);
			Employee emp4 = new Employee(2, "Annu", 17000);

			employeeIdMap.put(1, emp1);
			
			employeeIdMap.put(4, emp2);
			employeeIdMap.put(3, emp3);
			employeeIdMap.put(2, emp4);
		}

	}
	/**
	 * This is a getter method of HashMap
	 * @return HashMap<Integer, Country>
	 */
	public static HashMap<Integer, Employee> getEmployeeIdMap() {
		return employeeIdMap;
	}
	
}
