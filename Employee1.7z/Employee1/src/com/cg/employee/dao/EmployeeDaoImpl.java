package com.cg.employee.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.employee.beans.Employee;
import com.cg.employee.staticDB.EmployeeDB;

public class EmployeeDaoImpl implements IEmployeeDao {
	
	static HashMap<Integer, Employee> employeeIdMap = EmployeeDB.getEmployeeIdMap();

	@Override
	public List<Employee> getAllEmployeeDetails() {
		List<Employee> employees = new ArrayList<Employee>(employeeIdMap.values());
		return employees;
	}

	@Override
	public Employee getEmployee(int id) {
		Employee employee = employeeIdMap.get(id);
		return employee;
	}

	@Override
	public Employee addEmployee(Employee employee) {
		employeeIdMap.put(employee.getEmpId(), employee);
		return employee;
	}

	@Override
	public Employee deleteEmployee(int id) {
		return employeeIdMap.remove(id);
	}

}
