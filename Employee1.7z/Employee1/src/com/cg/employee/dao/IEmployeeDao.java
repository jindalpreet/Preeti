package com.cg.employee.dao;

import java.util.List;

import com.cg.employee.beans.Employee;

public interface IEmployeeDao {

	public List<Employee> getAllEmployeeDetails();
	public Employee getEmployee(int id);
	public Employee addEmployee(Employee employee);
	public Employee deleteEmployee(int id);
}
