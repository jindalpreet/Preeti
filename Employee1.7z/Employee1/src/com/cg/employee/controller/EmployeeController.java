package com.cg.employee.controller;

import java.util.List;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cg.employee.beans.Employee;
import com.cg.employee.service.EmployeeService;
import com.cg.employee.service.IEmployeeService;


@Path("/employees")
public class EmployeeController {
	IEmployeeService employeeService;

	public EmployeeController() {
		employeeService = new EmployeeService();
	}
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Employee> getEmployees() {
		List<Employee> listOfEmployees = employeeService.getAllEmployeeDetails();
		return listOfEmployees;
	}
	
	@POST
	@Path("/id")
	@Produces(MediaType.APPLICATION_JSON)
	public Employee getEmployeeById(@FormParam("txtId") int id) {
	
		
		Employee employee = employeeService.getEmployee(id);
		
		if (employee != null) {
			return employee;
		} else {
			return new Employee();
		}

		
		
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public Employee addEmployee(@FormParam("txtId") int txtId,
			@FormParam("txtName") String txtName,
			@FormParam("txtSalary") long txtSalary) {
		Employee employee = new Employee();
		employee.setEmpId(txtId);
		employee.setEmpName(txtName);
		employee.setSalary(txtSalary);
		return employeeService.addEmployee(employee);
	}
	
	@POST
	@Path("/delete")
	@Produces(MediaType.APPLICATION_JSON)
	public Employee deleteEmployee(@FormParam("txtId") int id) {
		Employee employee = employeeService.deleteEmployee(id);
	
		if (employee != null) {
			return employee;
		} else {
			return new Employee();
		}

	}
}
