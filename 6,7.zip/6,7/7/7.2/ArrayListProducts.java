import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class ArrayListProducts {

	public static void main(String[] args) {
		
		List<String>products = new ArrayList<>();
		
		products.add("Pen");
		products.add("Pencil");
		products.add("Book");
		products.add("Eraser");
		products.add("Notebook");
		
		Collections.sort(products);
		
		for (String string : products) {
			System.out.println(string);
		}
		
	}

}