package com.cg.eis.pl;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.Service;

public class ServiceMain {

	public static void main(String[] args) {
		
		Service service = new Service();
		Employee employee = new Employee();
		try{
			service.getEmployeeDetails(employee);
			service.setInsuranceScheme(employee);
			service.showEmployeeDetails(employee);
		}catch(EmployeeException exp){
			System.out.println(exp);
		}

	}

}
