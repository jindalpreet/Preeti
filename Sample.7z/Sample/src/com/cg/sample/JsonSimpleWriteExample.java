package com.cg.sample;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import org.json.simple.JSONObject;

public class JsonSimpleWriteExample {

    public static void main(String[] args)throws Exception
   	  {
   	  // We need to provide file path as the parameter:
   	  // double backquote is to avoid compiler interpret words
   	  // like \test as \t (ie. as a escape sequence)
   	
   /*	  
   	 ObjectMapper mapper = new ObjectMapper();
 
         File jsonInputFile = new File("D:\\Preeti.txt");
         Employee emp = mapper.readValue(jsonInputFile, Employee.class);
         System.out.println(emp);*/

        File jsonInputFile = new File("D:\\Preeti.txt");
   	  BufferedReader br = new BufferedReader(new FileReader(jsonInputFile));
   	  
   	  JSONObject obj = new JSONObject();
   	  String st;
   	  while ((st = br.readLine()) != null)
   		  
   	  {
        obj.put("details",st);
   	  }
   	 System.out.print(obj);
   	  
       /* try (FileWriter file1 = new FileWriter("D:\\test.json")) {

            file1.write(obj.toJSONString());
            file1.flush();

        }   catch (IOException e) {
            e.printStackTrace();
        }

        System.out.print(obj);*/

    }

}