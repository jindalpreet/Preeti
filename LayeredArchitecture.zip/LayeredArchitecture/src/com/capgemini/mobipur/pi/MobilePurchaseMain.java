package com.capgemini.mobipur.pi;





public class MobilePurchaseMain {

	public static void main(String[] args) {
	
	}

}
