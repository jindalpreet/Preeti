package com.capgemini.mobipur.test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.mobipur.service.IServiceMobile;
import com.capgemini.mobipur.service.ServiceMobileImpl;

public class ServiceMobileImplTest {

		private IServiceMobile servicePurchaseMobile;
		
	
	@Before
	public void setUp() throws Exception {
		servicePurchaseMobile = new ServiceMobileImpl();
		
	}

	@After
	public void tearDown() throws Exception {
		servicePurchaseMobile = null;
	}

	@Test
	public final void testSearch() {
		
	}

}
