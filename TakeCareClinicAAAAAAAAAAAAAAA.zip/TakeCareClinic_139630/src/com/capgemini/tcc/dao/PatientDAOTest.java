package com.capgemini.tcc.dao;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.tcc.bean.PatientBean;

public class PatientDAOTest {
	IPatientDAO pdao=new PatientDAO();
	

	@Test
	public void testAddPatientDetatils() {
		PatientBean patient=new PatientBean();
		patient.setPatient_Name("Swagata");
		patient.setAge(20);
		patient.setPhone("7890230176");
		patient.setDescription("fever");
		int id=pdao.addPatientDetatils(patient);
		
		assertTrue(0!=id);
		//fail("Not yet implemented");
	}


}
