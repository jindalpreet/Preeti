package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.tcc.DatabaseConn.DatabaseConn;
import com.capgemini.tcc.bean.PatientBean;

public class PatientDAO implements IPatientDAO {
	Logger log=Logger.getLogger(PatientDAO.class);
	public void logHistory(){
		log.info("inside PatientDAO class");
	}
	Connection conn = null;
	PreparedStatement pStmt = null;
	ResultSet rs=null;
	
	
	/*******************************************************************************************************
	 - Function Name	:	addPatientDetatils(PatientBean patient)
	 - Input Parameters	:	PatientBean patient
	 - Return Type		:	int
	 - Author			:	Swagata
	 - Creation Date	:	11/22/2017
	 - Description		:	Adding Patient
	 ********************************************************************************************************/

	@Override
	public int addPatientDetatils(PatientBean patient) {
		try {
			log.info("inside try");

			conn = DatabaseConn.getConnection();
			pStmt = conn.prepareStatement(OueryMapperTakeCareClinic.INSERTSQL);
			pStmt.setString(1, patient.getPatient_Name());
			pStmt.setInt(2, patient.getAge());
			pStmt.setString(3, patient.getPhone());
			pStmt.setString(4, patient.getDescription());
			pStmt.executeQuery();
			pStmt = conn.prepareStatement(OueryMapperTakeCareClinic.IDSQL);
			pStmt.setString(1, patient.getPhone());
			pStmt.setString(2, patient.getPatient_Name());
			pStmt.setInt(3, patient.getAge());
			pStmt.setString(4, patient.getDescription());
			ResultSet rs1=pStmt.executeQuery();
			while(rs1.next()){
				int id=(rs1.getInt("patient_id"));
				
				return id;
			}
			
			
		
				
			conn.commit();
		} catch (Exception e) {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				
				e1.printStackTrace();
			}
			log.error("error encountered");
			e.printStackTrace();
		}
		return 0;

	}
	
	
	/*******************************************************************************************************
	 - Function Name	:	searchPatientDetatils(int patientId)
	 - Input Parameters	:	int patientId
	 - Return Type		:	PatientBean
	 - Author			:	Swagata
	 - Creation Date	:	11/22/2017
	 - Description		:	Searching Patient
	 ********************************************************************************************************/


	@Override
	public PatientBean searchPatientDetatils(int patientId) {
		conn = DatabaseConn.getConnection();
		PatientBean patient=new PatientBean();
		try{
			log.info("inside try");
		pStmt = conn.prepareStatement(OueryMapperTakeCareClinic.SEARCHSQL);
		pStmt.setInt(1, patientId);
		rs=pStmt.executeQuery();
		while(rs.next()){
			patient.setPatient_Name(rs.getString("patient_name"));
			patient.setAge(rs.getInt("age"));
			patient.setConsultation_Date(rs.getDate("consultation_date"));
			patient.setDescription(rs.getString("description"));
			patient.setPhone(rs.getString("phone"));
			
			return patient;
		}
		conn.commit();
		
		}
		catch(Exception e){
			try {
				conn.rollback();
			} catch (SQLException e1) {
				
				e1.printStackTrace();
			}
			log.error("error encountered");
			e.printStackTrace();
		}
		
		return null;
		
	}


	@Override
	public PatientBean getPatientDetatils(int patientId) {
		
		return null;
	}
	

}
