package com.capgemini.tcc.DatabaseConn;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;



public class DatabaseConn {
	private static Connection conn=null;
	private DatabaseConn(){
		
	}
	
	
	public static Connection getConnection(){
		try{
			Properties prop = new Properties();
			InputStream is = DatabaseConn.class.getClassLoader().getResourceAsStream("dbms.properties");
			prop.load(is);
		
			Class.forName(prop.getProperty("driver"));
			conn = DriverManager.getConnection(prop.getProperty("url"),prop.getProperty("username"),prop.getProperty("password"));
			
			if(conn==null){
				return conn;
			}else{
				return conn;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		finally{
			return conn;
		}
		
		
	}
}
	
