package com.capgemini.tcc.exception;

public class TakeCareClinicException extends Exception {
	public TakeCareClinicException(String msg){
		super(msg);
	}

}
