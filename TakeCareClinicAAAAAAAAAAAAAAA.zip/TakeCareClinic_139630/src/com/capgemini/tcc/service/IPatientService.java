package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.TakeCareClinicException;

public interface IPatientService {
	public boolean isValid(PatientBean pb) throws TakeCareClinicException;

	public int addPatientDetails(PatientBean patient);

	public PatientBean getPatientDetails(int patientId);

	PatientBean search(int patientId);
}
